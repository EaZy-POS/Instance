Requirements:

VS 2017 Runtimes installed.

- Just install and add the below serial in registration window and click close in the window:

NAVP-KPJQ-REW2-AHJX
3

- Don't mind the Not Activated saying in license tab, your serial will be shown there and will be activated as Premium.